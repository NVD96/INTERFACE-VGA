This is MicroVGA arduino library
http://www.microvga.com/

Installation
--------------------------------------------------------------------------------

To install this library, just place this entire folder as a subfolder in your
Arduino/hardware/libraries folder.


Hardware
--------------------------------------------------------------------------------

Connect MicroVGA-TEXT to you Arduino as follows:

1 GND -> Arduino GND
2 +5V -> Arduino 5V
3 +3V3  NOT CONNECTED
4 CS# -> Arduino Digital 8
5 SCK -> Arduino Digital 13
6 RDY# -> Arduino Digital 9
7 MISO -> Arduino Digital 12
8 MOSI -> Arduino Digital 11



Building
--------------------------------------------------------------------------------

After this library is installed, you just have to start the Arduino application.
You may see a few warning messages as it's built.

To use this library in a sketch, go to the Sketch | Import Library menu and
select MicroVGA.  


This will add the following lines to your code:

#include <arduino_uvga.h>
#include <conio.h>
#include <kbd.h>
#include <ui.h>


First two lines are mandatory for all projects. If you do not need
user interface library (e.g. runmenu, drawfkeys, etc) you can omit the last line.

You sketch must call microvga_init routine in your setup() code, for example:


void setup()   {                
   microvga_init();
}

