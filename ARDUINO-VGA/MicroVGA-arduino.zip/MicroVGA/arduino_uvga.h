//  http://www.microvga.com/

#ifdef __cplusplus
extern "C" {
#endif


void microvga_init();


#ifdef  __cplusplus
}
#endif

