/*
  This file implements low-level routines for Arduino MicroVGA-TEXT.
  http://www.microvga.com/

  The MicroVGA has to be configured for SPI mode and connected as follows:

  
1 GND -> Arduino GND
2 +5V -> Arduino 5V
3 +3V3  NOT CONNECTED
4 CS# -> Arduino Digital 8
5 SCK -> Arduino Digital 13
6 RDY# -> Arduino Digital 9
7 MISO -> Arduino Digital 12
8 MOSI -> Arduino Digital 11

*/

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif
 
#include "conio.h"


// this is ugly hack if __builtin_avr_delay_cycles is not supported
#ifndef __builtin_avr_delay_cycles
void __builtin_avr_delay_cycles(unsigned long __n) {
while(__n)
__n--;
}
#endif


#if defined(__AVR_ATmega16__)
// Experimental "Arduino 16" board - feel free to change if there is an arduino w/ ATmega16

#define DD_RDY    0
#define DD_SS     1
#define DD_MOSI   5
#define DD_MISO   6
#define DD_SCK    7

#elif defined(__AVR_ATmega1280__)
// Arduino Mega Pin definitions

#define DD_SS 0 // PB0 | Arduino Mega Digital 53
#define DD_MOSI 2 // PB2 | Arduino Mega Digital 51
#define DD_MISO 3 // PB3 | Arduino Mega Digital 50
#define DD_SCK 1 // PB1 | Arduino Mega Digital 52
#define DD_RDY 4 // PB4 | Arduino Mega Digital 10

#else
// Arduino Duemilanove pin definitions

#define DD_RDY    0
#define DD_SS     1
#define DD_MOSI   3
#define DD_MISO   4
#define DD_SCK    5

#endif


#define DDR_SPI DDRB


void SPI_MasterTransmit(char cData)
{
    /* Start transmission */
   //SPDR = cData;
   SPDR = cData;
   
   /* Wait for transmission complete */
   while ( ! (SPSR & (1<<SPIF)))  ;
} 

#define KEYBUF_SIZE 10
unsigned char keybuf[KEYBUF_SIZE];
unsigned char khead, ktail;

char kbhit;
int _getch()
{
   int key;
   
   while (!_kbhit()) ;
   
   key = keybuf[khead];
   khead++;
   khead %= KEYBUF_SIZE;
   
   if (key == 0) {
       key = 0x100 | keybuf[khead];
       khead++;
       khead %= KEYBUF_SIZE;
   }
  
   return key;
}

int _kbhit()
{
  if (khead == ktail)
      _putch(0);
      
  if (khead == ktail)
     return 0;
     
  if (keybuf[khead] == 0 && ((khead+1)%KEYBUF_SIZE) == ktail) {
     _putch(0);
     if (keybuf[khead] == 0 && ((khead+1)%KEYBUF_SIZE) == ktail) 
       return 0;
  }
      
  return 1;
}


void _putch(char ch)
{
   unsigned char response;
  
   __builtin_avr_delay_cycles(100);
   PORTB &= ~(1<<DD_SS); // SS#=0
   __builtin_avr_delay_cycles(100);
    // wait for RDY signal to go low!
   while (PINB & (1<<DD_RDY) );   // PB0 is RDY input
   __builtin_avr_delay_cycles(100);
  
   /* Start transmission */
   //SPDR = cData;
   SPDR = ch;
   
   __builtin_avr_delay_cycles(100);
   
   /* Wait for transmission complete */
   while ( ! (SPSR & (1<<SPIF)));
   __builtin_avr_delay_cycles(100);
   
   response = SPDR;
   if (response != 0xFF) {
      keybuf[ktail] = response;
      ktail++;
      ktail %= KEYBUF_SIZE;
      kbhit = 1;
   } 
   
   __builtin_avr_delay_cycles(100);
   
   PORTB |= (1<<DD_SS); // PORTB1/SS#=0
} 


void microvga_init()
{
    kbhit = 0;
    khead = 0;
    ktail = 0;

   /* Set MOSI and SCK output all others input
      This agrees to AVR151 Table 1 also */

   DDRB = (1<<DD_MOSI) | (1<<DD_SCK) |  (1<<DD_SS); 
   
   DDRB &= ~(1<<DD_RDY); // PB0 is RDY input
   DDRB &= ~(1<<DD_MISO); // MISO is always input
   
   /* Enable SPI, Master, set clock rate fck/128 */
   SPCR = (1<<SPE) | (1<<MSTR) | (1<<SPR0) | (1<<CPHA);

}