﻿# bitluni's ESP32 VGA
A simple VGA output with 14Bit color and external DACs over parallel I²S

THanks for any support!

Patreon (https://patreon.com/bitluni)
Paypal (https://paypal.me/bitluni)

Version 0.1


#License
bitluni 2019
Creative Commons Attribution ShareAlike 2.0
https://creativecommons.org/licenses/by-sa/2.0/

If you need another license, please feel free to contact me