# Minimal-ATmega328P-VGA
VERY lightweight implementation of 320x200(400) VGA on an Arduino Nano mostly written in AVR Assembler inside the Arduino IDE...

...featuring a full 256 character set in FLASH memory!

See: https://www.youtube.com/channel/UCXYQcMpUBT3aaQKfmAVJNow
